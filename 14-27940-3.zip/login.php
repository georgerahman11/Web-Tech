<?php
error_reporting(0);
if (isset($_POST['submit'])){
	
	$login = trim($_POST['login']);
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	
	
	$c = mysqli_connect('loacalhost','root','','webtec');
	$sql = "insert into user values(".$id.",".$password.",'".$register.",')";
	
	mysqli_query($c,$sql);
	mysqli_close($c);
}



?>

<fieldset>
    <legend><b>LOGIN</b></legend>
    <form>
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>