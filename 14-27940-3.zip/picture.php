<?php







?>


<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form>
        <img width="128" src="../image/user.png" />
        <br />
        <input type="file">
        <hr />
        <input type="submit" value="Submit">
    </form>
</fieldset>
<input type="submit" value="Submit" >
		<br><a href="profile.php">Profile</a></br>
		<br><a href="profile.php">login</a></br>
		<br><a href="profile.php">password</a></br>
		<br><a href="profile.php">picture</a></br>