<?php
	if (isset($_POST['name'])){
	$name=$POST['name'];
	if (empty($_POST['name'])){
	echo "name is required";
	}
	}?>
					
<?php
	if (isset($_POST['email'])){
	$email=$POST['email'];
	if (empty($_POST['email'])){
	echo "email is required";
	}
	}?>
<?php
	if (isset($_POST['username'])){
	$userName=$POST['username'];
	if (empty($_POST['username'])){
	echo "username is required";
	}
	}?>
<?php
	if (isset($_POST['password'])){
	$pass=$POST['password'];
	if (empty($_POST['password'])){
	echo "password is required";
	}
	}?>
<?php
	if (isset($_POST['confirmPassword'])){
	$con=$POST['confirmPassword'];
	if (empty($_POST['confirmPassword'])){
	echo "confirmPassword is required";
	}
	}?>
	
<?php
	if (isset($_POST['a'])){
	$cd=$POST['a'];
	if (empty($_POST['a'])){
	echo "day is required";
	}
	}?>

<?php
	if (isset($_POST['b'])){
	$c=$POST['b'];
	if (empty($_POST['b'])){
	echo "month is required";
	}
	}?>

<?php
	if (isset($_POST['c'])){
	$ca=$POST['c'];
	if (empty($_POST['c'])){
	echo "year is required";
	}
	}?>
	
<?php
	if (isset($_POST['gender'])){
	$ca=$POST['gender'];
	if (empty($_POST['gender'])){
	echo "gender is required";
	}
	}?>
	
<?php
if (isset($_POST['submit'])){
	
    $id = trim($_POST['id']); 
	$name = trim($_POST['name']);
	$pass = trim($_POST['pass']);
	$repass = trim($_POST['repass']);
	$type = trim($_POST['type']);
	
	$c = mysqli_connect('localhost','root','','webtec');
	$sql = "insert into user values(".$id.",'".$name."','".$pass."','".$repass."')";
	
	mysqli_query($c,$sql);
	mysqli_close($c);
}



?>
	
	
<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form>
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text"></td>
		
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text"></td>
				
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password"></td>
				
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" value="Submit">
		<input type="reset">
	</form>
</fieldset>